const MissionState = {
  IDLE: "idle",
  IN_PROGRESS: "in_progress",
  CANCELED: "canceled",
  FINISHED: "finished"
};

export { MissionState };
